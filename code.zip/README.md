# vaelyna
Public version of my official discord bot. developed with Discord.js
